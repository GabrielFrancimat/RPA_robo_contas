# Desafios 3 e 4. A consulta operacional usa exclusivamente a interface.
SELETORES_V1 = dict(SELETORES)
SELETORES_V2 = dict(SELETORES, nf_numero='#nfNumero', nf_data='#nfData',
    nf_cnpj='#inputCnpjFornecedor', nf_fornecedor='#nfRazaoSocial',
    nf_descricao='#nfServico', nf_valor='#nfValorTotal', nf_cc='#selectCC',
    nf_gravar='#btnSalvarLancamento')


async def ler_registros_do_erp(robo) -> list[dict]:
    p = robo.page
    resposta = await p.goto(f'{ERP_URL}/notas')
    if '/login' in p.url:
        await robo.login()
        resposta = await p.goto(f'{ERP_URL}/notas')
    if resposta and resposta.status >= 500:
        raise ErroSistema(f'Consulta ao ERP: HTTP {resposta.status}')
    await p.locator('#tblNotas').wait_for()
    registros = []
    for linha in await p.locator('#tblNotas tr').all():
        valores = await linha.locator('td').all_inner_texts()
        if not valores:  # cabeçalho
            continue
        if len(valores) != 6:
            raise ErroSistema('Estrutura da tabela de notas mudou')
        protocolo, numero, cnpj, fornecedor, valor, centro = valores
        registros.append(dict(protocolo=protocolo.strip(), numero=numero.strip(),
            cnpj=limpar_cnpj(cnpj), fornecedor=fornecedor, valor=valor, centro_custo=centro))
    return registros


async def ler_notas_do_erp(robo) -> set:
    return {(n['numero'], n['cnpj']) for n in await ler_registros_do_erp(robo)}


async def lancar_por_rotulo(robo, nota) -> str:
    p = robo.page
    await p.goto(f'{ERP_URL}/nova-nota')
    if '/login' in p.url:
        await robo.login()
        await p.goto(f'{ERP_URL}/nova-nota')
    campos = {'Nº da NF': nota.numero, 'CNPJ fornecedor': limpar_cnpj(nota.cnpj),
        'Emissão (dd/mm/aaaa)': nota.data_emissao, 'Razão social': nota.prestador,
        'Descrição': nota.descricao, 'Valor (ex.: 1234,56)': f'{nota.valor:.2f}'.replace('.', ',')}
    for rotulo, valor in campos.items():
        await p.get_by_label(rotulo, exact=True).fill(valor)
    await p.get_by_label('Centro de custo', exact=True).select_option(nota.centro_custo)
    await p.get_by_role('button', name=re.compile(r'^(Gravar|Salvar lançamento)$')).click()
    desfecho = await p.wait_for_selector('#protocolo, #erroValidacao, #erroSistema')
    identificador = await desfecho.get_attribute('id')
    mensagem = (await desfecho.inner_text()).strip()
    if identificador == 'protocolo':
        return mensagem
    if identificador == 'erroSistema':
        raise ErroSistema(mensagem)
    raise ErroNegocio(f'ERP recusou: {mensagem}')


# Preserva a implementação por IDs para demonstrar as duas partes do desafio 4.
RoboERP.lancar_por_id = RoboERP.lancar
RoboERP.lancar = lancar_por_rotulo
